﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class PracticeTest
    {
        public int PracticeTestId { get; set; }
        public string TestName { get; set; }
        public string TestKey { get; set; }
        public string Description { get; set; }
        public int Time { get; set; }
        public int NoQuestionsA { get; set; }
        public int NoQuestionsB { get; set; }
        public bool AllowNegative { get; set; }
        public virtual FormalTest FormalTest { get; set; }
        public int  FormalTestId { get; set; }
    }
}