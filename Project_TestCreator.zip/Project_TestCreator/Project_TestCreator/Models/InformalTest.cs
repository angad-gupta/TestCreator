﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class InformalTest
    {
        public int InformalTestId { get; set; }
        public string TestName { get; set; }
        public string Description { get; set; }
        public int Time { get; set; }
        public int NoQuestions{ get; set; }
        public int HighestMarks { get; set; }
        public int NumberOfTakers { get; set; }
        public int FullMarks { get; set; }
        public int PassMarks { get; set; }
        public float PassRatio { get; set; }
        public virtual ICollection<Record> Records { get; set; }

        public virtual ICollection<Question> Questions { get; set; }

        public int SubCategoryId { get; set; }


    }
}