﻿using Project_TestCreator.Configuration;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class TCContext:DbContext
    {
          public TCContext()
            : base("TC")
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

         
            modelBuilder.Configurations.Add(new UsertypeConfiguration());
            modelBuilder.Configurations.Add(new AccountConfiguration());
            modelBuilder.Configurations.Add(new CreatorConfiguration());
            modelBuilder.Configurations.Add(new GiverConfiguration());
            modelBuilder.Configurations.Add(new AnswerConfiguration());
            modelBuilder.Configurations.Add(new CategoryConfiguration());
            modelBuilder.Configurations.Add(new FormalTestConfiguration());
            modelBuilder.Configurations.Add(new InformalTestConfiguration());
            modelBuilder.Configurations.Add(new  PracticeTestConfiguration());
            modelBuilder.Configurations.Add(new QuestionConfiguration());
            modelBuilder.Configurations.Add(new RecordConfiguration());
            modelBuilder.Configurations.Add(new ResultConfiguration());
            modelBuilder.Configurations.Add(new SubCategoryConfiguration());
            modelBuilder.Configurations.Add(new TemplateConfiguration());
            modelBuilder.Configurations.Add(new TestTemplateConfiguration());
            modelBuilder.Configurations.Add(new TestTypeConfiguration());


        }

        public DbSet<Usertype> Usertypes { get; set; }
        public DbSet<Account> Accounts { get; set; }
        public DbSet<Creator> Creators { get; set; }
        public DbSet<Giver> Givers { get; set; }
        public DbSet<Answer> Answers { get; set; }
        public DbSet<Category> Categorys { get; set; }
        public DbSet<FormalTest> FormalTests { get; set; }
        public DbSet<InformalTest> InformalTests { get; set; }
        public DbSet<PracticeTest> PracticeTests { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Record> Records { get; set; }
        public DbSet<Result> Results { get; set; }
        public DbSet<SubCategory> SubCategorys { get; set; }
        public DbSet<Template> Templates { get; set; }
        public DbSet<TestTemplate> TestTemplates { get; set; }
        public DbSet<TestType> TestTypes { get; set; }



    }
}