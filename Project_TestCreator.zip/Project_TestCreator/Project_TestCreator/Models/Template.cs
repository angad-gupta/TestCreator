﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class Template
    {
        public int TemplateId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string RollNo { get; set; }
        public string Nationality { get; set; }

        public virtual TestTemplate TestTemplate { get; set; }

        public virtual Result Result { get; set; }

        public int TestTemplateId { get;set;}

    }
}