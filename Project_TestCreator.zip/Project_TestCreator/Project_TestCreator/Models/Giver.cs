﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class Giver
    {
        public int GiverId { get; set; }
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string Info { get; set; }
        public string Photo { get; set; }
        public virtual Account Account { get; set; }
        public virtual ICollection<Record> Records { get; set; }
    }
}