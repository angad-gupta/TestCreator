﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class Question
    {
        public int QuestionId { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public int NoOption { get; set; }
        public bool IsMultipleAnswer { get; set; }
        public int Weight { get; set; }

        public int? FormalTestId { get; set; }
        public int? InformalTestId { get; set; }
        public int TestTypeId { get; set; }
        public virtual ICollection<Answer> Answers { get; set; }
        public virtual  TestType TestType { get; set; }

        public virtual  FormalTest FormalTest { get; set; }
        public virtual InformalTest InformalTest { get; set; }
    }
}