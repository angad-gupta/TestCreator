﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class TestTemplate
    {
        public int TestTemplateId { get; set; }
        public int Code { get; set; }


        public virtual FormalTest FormalTest { get;set;}
        public virtual ICollection<Template> Templates { get; set; }

    }
}