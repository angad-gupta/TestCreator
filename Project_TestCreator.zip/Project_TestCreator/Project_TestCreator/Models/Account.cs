﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class Account
    {
        public int AccountId { get; set; }

        public int UsertypeId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public virtual Usertype Usertype { get; set; }
        public virtual Creator Creator { get; set; }
        public virtual Giver  Giver{ get; set; }

    }
}