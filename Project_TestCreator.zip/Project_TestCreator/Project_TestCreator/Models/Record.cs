﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class Record
    {
        public int RecordId { get; set; }
        public float Marks { get; set; }
        public bool IsPass { get; set; }

        public virtual Giver Giver { get; set; }

        public virtual InformalTest InformalTest { get; set; }

        public int GiverId { get; set; }
        public int InformalTestId { get; set; }


    }
}