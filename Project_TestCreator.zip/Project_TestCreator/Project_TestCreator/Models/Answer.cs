﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class Answer
    {
        public int AnswerId { get; set; }
        public int QuestionId { get; set; }
        public string Description { get; set; }
        public bool IsCorrect { get; set; }
        public virtual Question Question { get; set; }

    }
}