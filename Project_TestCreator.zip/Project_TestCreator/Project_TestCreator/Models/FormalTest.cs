﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class FormalTest
    {
        public int FormalTestId { get; set; }

        public int CreatorId { get; set; }
        public string TestName { get; set; }
        public string TestKey { get; set; }
        public string Description { get; set; }
        public string Password { get; set; }
        public int NumberOfTakers { get; set; }
        public int Time { get; set; }
        public int NoQuestionsA { get; set; }
        public int NoQuestionsB { get; set; }
        public DateTime? ActivatedDate { get; set; }
        public DateTime? ExpiredDate { get; set; }
        public bool IsActive { get; set; }
        public bool AllowNegative { get; set; }
        public virtual Creator Creator { get; set; }
        public virtual ICollection<Result>  Results { get; set; }
        public virtual TestTemplate TestTemplate { get; set; }
        public virtual ICollection<PracticeTest> PracticeTests { get; set; }
        public virtual ICollection<Question> Questions{ get; set; }
    }
}