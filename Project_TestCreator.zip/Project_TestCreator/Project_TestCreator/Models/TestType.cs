﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class TestType
    {
        public int TestTypeId { get; set; }
        public string TestTypeName { get; set; }

        public virtual ICollection<Question> Questions { get; set; }

        
    }
}