﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class Usertype
    {
        public int UsertypeId { get; set; }
        public string UsertypeName { get; set; }

        public virtual ICollection<Account> Accounts { get; set; }
    }
}