﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class Result
    {
        public int ResultId { get; set; }
        public float Marks { get; set; }
        public bool IsPass { get; set; }
        public int AttemptedQuestions { get; set; }
        public int CreatorId{ get; set; }
        public int FormalTestId{ get; set; }
        public   virtual Creator Creator  { get; set; }
        public   virtual FormalTest FormalTest  { get; set; }
        public   virtual Template Template  { get; set; }


    }
}