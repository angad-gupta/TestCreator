﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Models
{
    public class Creator
    {
        public int CreatorId { get; set; }
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string Info { get; set; }
        public string Photo { get; set; }
        public virtual Account Account { get; set; }
        public virtual ICollection<FormalTest>  FormalTests { get; set; }
        public virtual ICollection<Result> Results { get; set; }
    }
}