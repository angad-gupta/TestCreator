﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class InformalTestConfiguration:EntityTypeConfiguration<InformalTest>
    {
        public InformalTestConfiguration()
        {
            ToTable("InformalTest");
            HasKey(x => x.InformalTestId);
     //       HasRequired(x=>x.)
        }
    }
}