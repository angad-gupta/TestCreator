﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class TemplateConfiguration:EntityTypeConfiguration<Template>
    {
        public TemplateConfiguration()
        {
            ToTable("Template");
            HasKey(x => x.TemplateId);
            HasRequired(x => x.TestTemplate).WithMany(x => x.Templates).HasForeignKey(x => x.TestTemplateId);
            HasRequired(x => x.Result).WithRequiredPrincipal(x => x.Template).WillCascadeOnDelete(false);
        }
    }
}