﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class RecordConfiguration:EntityTypeConfiguration<Record>
    {
        public RecordConfiguration()
        {
            ToTable("Record");
            HasKey(x => x.RecordId);
            HasRequired(x => x.Giver).WithMany(x => x.Records).HasForeignKey(x => x.GiverId);
            HasRequired(x => x.InformalTest).WithMany(x => x.Records).HasForeignKey(x => x.InformalTestId);
        }
    }
}