﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class ResultConfiguration:EntityTypeConfiguration<Result>
    {
        public ResultConfiguration()
        {
            ToTable("Result");
            HasKey(x=>x.ResultId);
            HasRequired(x => x.Creator).WithMany(x => x.Results).HasForeignKey(x=>x.CreatorId).WillCascadeOnDelete(false);
            HasRequired(e => e.FormalTest).WithMany(w => w.Results).HasForeignKey(x => x.FormalTestId).WillCascadeOnDelete(false);

        }

    }
}