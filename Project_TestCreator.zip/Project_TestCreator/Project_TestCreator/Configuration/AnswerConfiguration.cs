﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class AnswerConfiguration:EntityTypeConfiguration<Answer>
    {
        public AnswerConfiguration()
        {
            ToTable("Answer");
            HasKey(x => x.AnswerId);
            HasRequired(x => x.Question).WithMany(x => x.Answers).HasForeignKey(x => x.QuestionId);
        }
    }
}