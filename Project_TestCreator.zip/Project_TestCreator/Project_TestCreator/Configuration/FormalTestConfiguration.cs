﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class FormalTestConfiguration:EntityTypeConfiguration<FormalTest>
    {
        public FormalTestConfiguration()
        {
            ToTable("FormalTest");
            HasKey(x=>x.FormalTestId);
            HasRequired(x => x.Creator).WithMany(x => x.FormalTests).HasForeignKey(x=>x.CreatorId);
        }
    }
}