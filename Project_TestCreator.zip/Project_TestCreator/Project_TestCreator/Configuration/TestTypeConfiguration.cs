﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class TestTypeConfiguration:EntityTypeConfiguration<TestType>
    {
        public TestTypeConfiguration()
        {
            ToTable("TestType");
            HasKey(x => x.TestTypeId);
         //   HasRequired
        }
    }
}