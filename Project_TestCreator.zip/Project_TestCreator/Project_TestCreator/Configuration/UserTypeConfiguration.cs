﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class UsertypeConfiguration:EntityTypeConfiguration<Usertype>
    {
        public UsertypeConfiguration()
        {
            ToTable("Usertype");
            HasKey(x => x.UsertypeId);
        }
    }
}