﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class GiverConfiguration:EntityTypeConfiguration<Giver>
    {
        public GiverConfiguration(){
            ToTable("Giver");
            HasKey(x => x.GiverId);
            HasRequired(x => x.Account).WithRequiredDependent(x => x.Giver).WillCascadeOnDelete(false);
        
    }
    }
}