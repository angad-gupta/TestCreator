﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class CreatorConfiguration : EntityTypeConfiguration<Creator>
    {
        public CreatorConfiguration()
        {
            ToTable("Creator");
            HasKey(x => x.CreatorId);
            HasRequired(x => x.Account).WithRequiredDependent(x => x.Creator).WillCascadeOnDelete(false);


        }
    }
}