﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class AccountConfiguration : EntityTypeConfiguration<Account>
    {
        public AccountConfiguration()
        {
            ToTable("Account");
            HasKey(x => x.AccountId);
            HasRequired(x => x.Usertype).WithMany(x => x.Accounts).HasForeignKey(x => x.UsertypeId); 
           
        }

    }
}