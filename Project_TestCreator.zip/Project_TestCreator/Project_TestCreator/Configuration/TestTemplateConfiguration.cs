﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class TestTemplateConfiguration:EntityTypeConfiguration<TestTemplate>
    {
        public TestTemplateConfiguration()
        {
            ToTable("TestTemplate");
            HasKey(x => x.TestTemplateId);
            HasRequired(x => x.FormalTest).WithRequiredDependent(x => x.TestTemplate).WillCascadeOnDelete(false);
        }
    }
}