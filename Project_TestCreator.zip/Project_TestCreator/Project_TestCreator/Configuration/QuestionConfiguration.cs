﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace Project_TestCreator.Configuration
{
    public class QuestionConfiguration:EntityTypeConfiguration<Question>
    {
        public QuestionConfiguration()
        {
            ToTable("Question");
            HasKey(x => x.QuestionId);
            HasOptional(x => x.FormalTest).WithMany(x => x.Questions).HasForeignKey(x => x.FormalTestId);
            HasRequired(x => x.TestType).WithMany(x => x.Questions).HasForeignKey(x => x.TestTypeId);
            HasOptional(x => x.InformalTest).WithMany(x => x.Questions).HasForeignKey(x => x.InformalTestId);
        }
    }
}