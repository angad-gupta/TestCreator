﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Project_TestCreator.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        TCContext TC= new TCContext();
        public ActionResult Index()
        {
            TCContext tc = new TCContext();
           // Usertype u = new Usertype { UsertypeName = "Creator" };
           // Usertype v = new Usertype { UsertypeName = "Giver" };
           // tc.Usertypes.Add(u);
           // tc.Usertypes.Add(v);
           // tc.SaveChanges();
            return View();
        }
        //public ActionResult Register(FormCollection f)
        //{
        //   // Account a = new Account();
        //   // a.Password=f['password'];
        //   // a.UserName=f['username'];
        //   // a.UserName=f['firstname']+" "+f['lastname'];
        //   //TC.Accounts.Add(a);
        //   // TC.SaveChanges();
        //   // List<FormalTest> g=TC.Accounts.Single(x=>x.AccountId==1).Creator.FormalTests.ToList()
        //   return RedirectToAction('Index');
        //}

      public ActionResult Register(FormCollection f)
      {
          Account a = new Account();
        
          a.UserName = f["username"];
          a.Password = f["password"];
          a.UsertypeId = 1;
          
          TC.Accounts.Add(a);
          TC.SaveChanges();
         
          return View();
       // return RedirectToAction("Register");
      }

      //  public ActionResult Register(int id)
      //{
      //    Account A = TC.Accounts.Single(x => x.AccountId == id);
      //    ViewBag.username = A.UserName;
      //    return View();
      //}
      public JsonResult CheckUserName(string username)
      {
          var result = 't';
          if (username == "abc")
              result = 't';
          return Json(result);
      }
      public ActionResult Login(string UserName, string Password)
      {
          if (TC.Accounts.Any(x => x.UserName == UserName && x.Password == Password))
          {
              int id = TC.Accounts.Single(x => x.UserName == UserName && x.Password == Password).AccountId;
              return RedirectToAction("ProfileView", "Profile", new { id = id });
          }
          else
              return PartialView();
      }
      public ActionResult Validate(FormCollection f)
      {
          string errormessage = "Incorrect Password";
          string password = f["password"];

          string repassword = f["repassword"];

          if (password != repassword)
          {
              var result = errormessage;
              return Json(result, JsonRequestBehavior.AllowGet);
          }
          return View();
      }

private ActionResult RedirectToAction(char p)
{
 	throw new NotImplementedException();
}
        public ActionResult Test()
        {
            
            Account a = new Account(){UserName="asdasd", Password="asdasd"};
            ViewBag.acc = a;
            return View();
        }
    }
}
