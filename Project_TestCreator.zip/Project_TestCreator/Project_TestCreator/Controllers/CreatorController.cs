﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Project_TestCreator.Controllers
{
    public class CreatorController : Controller
    {
        //
        // GET: /Creator/

        public ActionResult CreatorView()
        {
            return View();
        }

    }
}
