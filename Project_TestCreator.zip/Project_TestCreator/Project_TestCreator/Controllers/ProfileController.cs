﻿using Project_TestCreator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Project_TestCreator.Controllers
{
    public class ProfileController : Controller
    {
        //
        // GET: /Profile/
        TCContext TC = new TCContext();

        public ActionResult ProfileView(int id)
        {
            Account A = TC.Accounts.Single(x => x.AccountId == id);
            ViewBag.username = A.UserName;
           
            return View();
        }

    }
}
