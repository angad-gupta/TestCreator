﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Project_TestCreator.Controllers
{
    public class FormalTestController : Controller
    {
        //
        // GET: /FormalTest/

        public ActionResult FormalTestView()
        {
            return View();
        }

    }
}
